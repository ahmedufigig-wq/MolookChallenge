package com.molook.challenge

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.security.MessageDigest

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 15)
    private val panel = Color.rgb(27, 27, 32)
    private val gold = Color.rgb(224, 180, 75)
    private val white = Color.rgb(246, 244, 238)
    private val muted = Color.rgb(175, 172, 164)
    private val prefs by lazy { getSharedPreferences("molook_local", Context.MODE_PRIVATE) }

    data class Q(val question: String, val answers: List<String>, val correct: Int, val category: String)
    private val questions = listOf(
        Q("ما عاصمة اليمن؟", listOf("عدن", "صنعاء", "تعز", "إب"), 1, "ثقافة"),
        Q("كم عدد أيام الأسبوع؟", listOf("5", "6", "7", "8"), 2, "عام"),
        Q("أي كوكب يُعرف بالكوكب الأحمر؟", listOf("الزهرة", "المريخ", "زحل", "عطارد"), 1, "علوم"),
        Q("ما ناتج 9 × 7؟", listOf("56", "63", "72", "69"), 1, "رياضيات"),
        Q("أي حيوان يُلقب بسفينة الصحراء؟", listOf("الحصان", "الجمل", "الفيل", "الغزال"), 1, "ثقافة"),
        Q("كم ضلعًا للمثلث؟", listOf("2", "3", "4", "5"), 1, "رياضيات"),
        Q("ما اللغة الرسمية في البرازيل؟", listOf("الإسبانية", "البرتغالية", "الفرنسية", "الإنجليزية"), 1, "جغرافيا"),
        Q("أي عضو يضخ الدم في الجسم؟", listOf("الرئة", "الكبد", "القلب", "المعدة"), 2, "علوم"),
        Q("كم دقيقة في الساعة؟", listOf("30", "45", "60", "90"), 2, "عام"),
        Q("ما أكبر محيط على الأرض؟", listOf("الأطلسي", "الهندي", "المتجمد", "الهادئ"), 3, "جغرافيا")
    )

    private var index = 0
    private var score = 0
    private var answered = false
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showLogin()
    }

    private fun base(title: String, subtitle: String? = null) {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(body)
        setContentView(scroll)
        text(title, 28, gold, true, Gravity.CENTER)
        if (subtitle != null) text(subtitle, 14, muted, false, Gravity.CENTER)
        space(18)
    }

    private fun showLogin() {
        base("♛ ملوك التحدّي", "إصدار اللمة • العب بذكاء، وافز بجدارة")
        card {
            text("مرحبًا بك أيها المنافس", 20, white, true, Gravity.CENTER)
            space(8)
            text("أنشئ اسم لاعب ورمز PIN محليًا على هذا الهاتف.", 14, muted, false, Gravity.CENTER)
            space(16)
            val name = EditText(this).apply {
                hint = "اسم اللاعب"
                setHintTextColor(muted); setTextColor(white)
                textDirection = View.TEXT_DIRECTION_RTL
                setSingleLine(true)
            }
            val pin = EditText(this).apply {
                hint = "رمز PIN من 4 إلى 6 أرقام"
                setHintTextColor(muted); setTextColor(white)
                inputType = 2
                setSingleLine(true)
            }
            body.addView(name, matchWrap())
            space(10)
            body.addView(pin, matchWrap())
            space(14)
            button("دخول / إنشاء حساب") {
                val n = name.text.toString().trim()
                val p = pin.text.toString()
                if (n.isBlank() || p.length !in 4..6 || !p.all { it.isDigit() }) {
                    toast("أدخل اسمًا ورمز PIN من 4 إلى 6 أرقام")
                } else {
                    val existing = prefs.getString("pin_hash", null)
                    val hash = sha256(p)
                    if (existing == null) {
                        prefs.edit().putString("player_name", n).putString("pin_hash", hash).apply()
                        showHome()
                    } else if (existing == hash) {
                        prefs.edit().putString("player_name", n).apply()
                        showHome()
                    } else {
                        toast("رمز PIN غير صحيح على هذا الجهاز")
                    }
                }
            }
        }
        space(16)
        text("ملاحظة: الحساب محفوظ على هذا الهاتف فقط.", 12, muted, false, Gravity.CENTER)
    }

    private fun showHome() {
        val name = prefs.getString("player_name", "لاعب") ?: "لاعب"
        base("♛ ملوك التحدّي", "أهلًا $name — مستعد للتحدّي؟")
        card {
            text("ملف اللاعب", 19, gold, true)
            space(6)
            text("النقاط الكلية: ${prefs.getInt("total_score", 0)}", 16, white)
            text("عدد الانتصارات: ${prefs.getInt("wins", 0)}", 16, white)
            text("أفضل نتيجة: ${prefs.getInt("best_score", 0)}", 16, white)
        }
        space(14)
        button("ابدأ تحدي الأسئلة") { index = 0; score = 0; showQuestion() }
        space(10)
        button("إحصائياتي") { showStats() }
        space(10)
        button("طريقة اللعب دون إنترنت") {
            info("طريقة اللعب", "هذه النسخة الأولية تعمل محليًا على جهاز واحد. الاتصال الجماعي عبر نقطة اتصال Wi‑Fi لم يُنفذ بعد في هذه النسخة.")
        }
        space(10)
        button("تسجيل الخروج") { showLogin() }
    }

    private fun showQuestion() {
        if (index >= questions.size) { finishQuiz(); return }
        answered = false
        val q = questions[index]
        base("الجولة ${index + 1} من ${questions.size}", q.category)
        card {
            text(q.question, 22, white, true, Gravity.CENTER)
            space(16)
            q.answers.forEachIndexed { i, answer ->
                button(answer) {
                    if (!answered) {
                        answered = true
                        if (i == q.correct) {
                            score += 10
                            toast("إجابة صحيحة! +10 نقاط")
                        } else toast("إجابة غير صحيحة")
                        index++
                        body.postDelayed({ showQuestion() }, 650)
                    }
                }
                space(8)
            }
        }
        space(12)
        text("النقاط في هذه الجولة: $score", 16, gold, true, Gravity.CENTER)
    }

    private fun finishQuiz() {
        val oldTotal = prefs.getInt("total_score", 0)
        val oldBest = prefs.getInt("best_score", 0)
        val wins = prefs.getInt("wins", 0) + if (score >= 50) 1 else 0
        prefs.edit().putInt("total_score", oldTotal + score)
            .putInt("best_score", maxOf(oldBest, score))
            .putInt("wins", wins).apply()
        base("انتهى التحدّي!", "نتيجتك النهائية")
        card {
            text("$score نقطة", 34, gold, true, Gravity.CENTER)
            space(8)
            text(if (score >= 50) "أداء رائع! أنت نجم التحدّي 👑" else "أحسنت المشاركة، حاول تحطيم رقمك!", 17, white, true, Gravity.CENTER)
        }
        space(16)
        button("العب مرة أخرى") { index = 0; score = 0; showQuestion() }
        space(10)
        button("الصفحة الرئيسية") { showHome() }
    }

    private fun showStats() {
        base("إحصائياتي", "إحصائيات محفوظة على الجهاز")
        card {
            text("اللاعب: ${prefs.getString("player_name", "لاعب")}", 17, white)
            text("إجمالي النقاط: ${prefs.getInt("total_score", 0)}", 17, gold, true)
            text("أفضل نتيجة: ${prefs.getInt("best_score", 0)}", 17, white)
            text("الانتصارات (نتيجة 50+): ${prefs.getInt("wins", 0)}", 17, white)
        }
        space(14)
        button("رجوع") { showHome() }
    }

    private fun card(content: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            setBackgroundColor(panel)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        body.addView(box, matchWrap())
        val old = body
        body = box
        content()
        body = old
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean = false, gravity: Int = Gravity.RIGHT) {
        val v = TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            this.gravity = gravity
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(4), dp(2), dp(4))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        body.addView(v, matchWrap())
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setTextColor(Color.BLACK)
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setBackgroundColor(gold)
            isAllCaps = false
            setOnClickListener { action() }
        }
        body.addView(b, matchWrap())
    }

    private fun space(px: Int) {
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(px)))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(2) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun info(title: String, message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle(title).setMessage(message)
            .setPositiveButton("حسنًا", null).show()
    }
}
